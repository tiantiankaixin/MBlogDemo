//
//  UIView+frame.h
//  UnitTest
//
//  Created by mal on 2018/8/28.
//  Copyright © 2018年 mal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MSetFrame.h"

@interface UIView (frame)

- (MSetFrame *)mset;

@end
